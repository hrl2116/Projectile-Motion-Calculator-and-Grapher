##############################
# Name: Hannah Luo
# UNI: hrl2116
#
# File has functions that allow the user to enter the name of the file and
# then the program can read and open it
##############################

def parseCSV(filename):
    '''
    Read the file called "filename", expected to be a csv file.

    Return the data as a list-of-lists
    '''
    ret = []
    
    #creates a list-of-lists
    with open(filename, 'r') as file:
        for element in file:
            x = element.split(',')
            ret.append(x)

    return ret


def askConfig():
    '''
    Ask the user for the following config variables:
        filename: the name of the csv file
    Returns the information as a dictionary
    '''  
    filename = input("Enter the name of your csv file: ")
    # return a dictionary
    ret = {"filename": filename}
    return ret