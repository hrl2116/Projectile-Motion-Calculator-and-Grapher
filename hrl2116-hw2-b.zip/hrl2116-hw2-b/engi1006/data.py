##############################
# Name: Hannah Luo
# UNI: hrl2116
#
# File returns the dataset size
##############################

def datasetInfo(dataset):
    '''
    Takes the dataset as an N x M list of lists.

    Returns the following statistics as a dictionary:
        rows: N from above, as an integer
        columns: M from above, as an integer
    '''
    rows = len(dataset)
    cols = len(dataset[0])
    
    # return a dictionary
    ret = {"rows": rows, "columns": cols}

    return ret