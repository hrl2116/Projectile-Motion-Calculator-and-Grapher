﻿UNI: hrl2116
Name: Hannah Luo
HW Number: 2B


For 2B1: 
* s_standard, s_next, v_next, and grav(s) are all pretty straightforward and sufficiently explained by the docstring and comments, so I will not explain them further in this readMe
* s_sim first initializes g, v, and s. g is initialized as grav(s_0) since s_0 is passed in as a parameter in the function. s and v are also initialized to the parameters passed in through the method. Then, I utilize a for-loop that iterates t/delta_t times, so that it will update the values at each point on the graph I want. Within the for loop, I update s, v, and g by defining themselves in terms of their old values.
* plot_trajectories first creates a list of the x values, the first value initialized at 0 to represent time at 0 seconds. Then, I have a list of the y_s_formula values for the y values returned by s_standard and then a list y_s_sim to store the y values returned by s_sim. I use the while loop with the condition that the s_standard and s_sim values are greater than or equal to 0, since we are only concerned with the projectile during the time it is in the air. Within the while loop, I calculate the values returned by the two different projectile measuring methods and then append them to the appropriate list. After the while loop, I calculate the differences and put them in their own list called differences using a for loop. Finally, I use the code provided in class and Piazza to plot y_s_formula, y_s_sim, and differences with respect to time (x).


For 2B2:
* Note: for __init__.py, I had to modify the import statements because the provided skeleton code was incorrect
* datasetInfo takes in a dataset and initializes the variables rows and cols to the number of rows and columns in the the dataset, respectively, by using the len() method. It then creates a dictionary called ret which holds these values and returns ret.
* parseCSV opens the file in read mode using ‘r’ and then uses a for loop to iterate through each line of the csv file. For each line, a temporary variable, x, is assigned to a list of all the values in the line by using the split() function with ‘,’ as a parameter, which returns a list of values that were originally separated in the csv by commas. Then, they are appended to a list called ret. At the end of the function, ret is returned.
* askConfig asks the user for the filename by using the input() method. Then, the filename is put in a dictionary called ret and ret is returned.