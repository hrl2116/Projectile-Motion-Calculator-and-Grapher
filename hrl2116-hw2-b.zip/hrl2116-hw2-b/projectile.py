##############################
# Name: Hannah Luo
# UNI: hrl2116
#
# File contains functions that simulate a projectile being fired straight up 
# in the air
##############################

import matplotlib.pyplot as plt

'''Initializing instance variables'''
gravity = 9.81
G = 6.6742*10**-11
Me = 5.9736*10**24
Re = 6371000

def s_standard(t, v_0):
    '''returns the position using the standard equation with gravity
    as a constant'''
    s = -0.5 * gravity * t**2 + v_0 * t
    return s

    
def s_sim(t, v_0, s_0, delta_t):
    '''returns the position using the equation where gravity changes with the
    position of the projectile'''
    g = grav(s_0)
    v = v_0
    s = s_0
    
    # this for loop repeats t/delta_t times and updates position, velocity,
    # and gravity in increments of delta_t
    for i in range (0, int(t/delta_t)):
        s = s_next(s, v, delta_t)
        v = v_next(v, g, delta_t)
        g = grav(s)
    return s


def s_next(s, v, delta_t):
    '''calculates and returns s(t + delta_t)'''
    s_final = s + v * delta_t
    return s_final


def v_next(v, g, delta_t):
    '''calculates and returns v(t + delta_t)'''
    v_final = v - g * delta_t
    return v_final


def grav(s):
    '''calculates and returns gravity as a function of position'''
    return G * Me / ((Re + s)**2)


def plot_trajectories(v_0, s_0, delta_t):
    '''plots the entire trajectories of the two methods and the difference
    in value between them'''
    #initializing the x and y arrays at 0 seconds
    x = [0]
    y_s_formula = [s_0]
    y_s_sim = [s_0]    
    s_f = s_0
    s_s = s_0
    t = 0
    
    # while the projectile is still in the air, increment the time by 1 second
    # and update the values returned by s_standard and s_sim, then append
    # those values to the corresponding y arrays and append the time to the 
    # x array
    while s_f >= 0 and s_s >= 0:
        t = t + 1
        s_f = s_standard(t, v_0)
        s_s = s_sim(t, v_0, s_0, delta_t)
        
        y_s_formula.append(s_f)
        y_s_sim.append(s_s)
        x.append(t)
    
    #calculating the differences
    differences = [(y_s_sim[i] - y_s_formula[i]) for i in range(t + 1)]
    
    # create two subplots
    f, (ax1, ax2) = plt.subplots(2, 1, sharex = True)
    
    # Plot the 2 trajectories
    ax1.plot(x, y_s_formula, color = 'r')
    ax1.plot(x, y_s_sim, color = 'b')
    
    # plot the differences
    ax2.plot(x, differences, c = 'g')
    
    # show plot
    plt.show()
    
